import { Card, CardContent } from "@/components/ui/card";

export default function Settings() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-foreground mb-2">Settings</h1>
      <p className="text-muted-foreground mb-8">Configure system preferences</p>
      
      <Card className="border-border">
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">Settings page coming soon</p>
        </CardContent>
      </Card>
    </div>
  );
}
