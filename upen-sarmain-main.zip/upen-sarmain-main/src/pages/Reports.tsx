import { Card, CardContent } from "@/components/ui/card";

export default function Reports() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-foreground mb-2">Reports</h1>
      <p className="text-muted-foreground mb-8">Generate and export accountability reports</p>
      
      <Card className="border-border">
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">Reports generation coming soon</p>
        </CardContent>
      </Card>
    </div>
  );
}
