import { Card, CardContent } from "@/components/ui/card";

export default function Investigations() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-foreground mb-2">Investigations</h1>
      <p className="text-muted-foreground mb-8">Manage ongoing and completed investigations</p>
      
      <Card className="border-border">
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">Investigations management coming soon</p>
        </CardContent>
      </Card>
    </div>
  );
}
