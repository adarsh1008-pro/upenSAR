import { useParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  FileText, 
  Users, 
  History, 
  Upload, 
  Brain,
  Download,
  Eye
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AccountDetails() {
  const { accountNo } = useParams();

  const accountInfo = {
    accountNo: accountNo || "ACC-456789",
    customerName: "ABC Enterprises Ltd.",
    type: "Term Loan",
    branch: "Central Branch",
    status: "NPA",
    outstandingAmount: "₹45,00,000",
    sanctionDate: "2023-05-15",
    sanctionAuthority: "Regional Manager"
  };

  const staffDetails = [
    {
      name: "Rajesh Kumar",
      role: "Credit Officer",
      employeeId: "EMP-1234",
      stage: "Processing"
    },
    {
      name: "Priya Sharma",
      role: "Branch Manager",
      employeeId: "EMP-5678",
      stage: "Sanctioning"
    },
    {
      name: "Amit Patel",
      role: "Operations Officer",
      employeeId: "EMP-9012",
      stage: "Disbursal"
    }
  ];

  const documents = [
    {
      name: "Loan Application Form",
      type: "Application",
      uploadedBy: "Rajesh Kumar",
      date: "2023-05-10",
      status: "Analyzed"
    },
    {
      name: "Sanction Memo",
      type: "Approval",
      uploadedBy: "Priya Sharma",
      date: "2023-05-14",
      status: "Pending Review"
    },
    {
      name: "Financial Statements",
      type: "Supporting",
      uploadedBy: "Rajesh Kumar",
      date: "2023-05-08",
      status: "Summarized"
    }
  ];

  const actionLogs = [
    {
      action: "Document Uploaded",
      description: "Financial Statements uploaded",
      user: "Rajesh Kumar",
      timestamp: "2023-05-08 10:30 AM"
    },
    {
      action: "Approval",
      description: "Loan sanctioned by Branch Manager",
      user: "Priya Sharma",
      timestamp: "2023-05-14 02:15 PM"
    },
    {
      action: "Investigation Initiated",
      description: "SAR investigation started",
      user: "John Smith",
      timestamp: "2025-10-28 09:00 AM"
    }
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Account Details</h1>
            <p className="text-muted-foreground mt-1">{accountInfo.accountNo}</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="gap-2">
              <Upload className="h-4 w-4" />
              Upload Document
            </Button>
            <Button className="gap-2">
              <Brain className="h-4 w-4" />
              Investigate
            </Button>
          </div>
        </div>
      </div>

      {/* Primary Account Details */}
      <Card className="mb-6 border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Primary Account Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Customer Name</p>
              <p className="font-semibold text-foreground mt-1">{accountInfo.customerName}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Account Type</p>
              <p className="font-semibold text-foreground mt-1">{accountInfo.type}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Branch</p>
              <p className="font-semibold text-foreground mt-1">{accountInfo.branch}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Status</p>
              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 mt-1">
                {accountInfo.status}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Outstanding Amount</p>
              <p className="font-semibold text-foreground mt-1">{accountInfo.outstandingAmount}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Sanction Date</p>
              <p className="font-semibold text-foreground mt-1">{accountInfo.sanctionDate}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Sanction Authority</p>
              <p className="font-semibold text-foreground mt-1">{accountInfo.sanctionAuthority}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs for Details */}
      <Tabs defaultValue="staff" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="staff" className="gap-2">
            <Users className="h-4 w-4" />
            Staff Details
          </TabsTrigger>
          <TabsTrigger value="documents" className="gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="logs" className="gap-2">
            <History className="h-4 w-4" />
            Action Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="staff" className="mt-6">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Staff Involvement</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-border">
                    <TableHead>Name</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Employee ID</TableHead>
                    <TableHead>Involvement Stage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {staffDetails.map((staff, index) => (
                    <TableRow key={index} className="border-border">
                      <TableCell className="font-medium">{staff.name}</TableCell>
                      <TableCell>{staff.role}</TableCell>
                      <TableCell>{staff.employeeId}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{staff.stage}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="mt-6">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Documents</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-border">
                    <TableHead>Document Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Uploaded By</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documents.map((doc, index) => (
                    <TableRow key={index} className="border-border">
                      <TableCell className="font-medium">{doc.name}</TableCell>
                      <TableCell>{doc.type}</TableCell>
                      <TableCell>{doc.uploadedBy}</TableCell>
                      <TableCell>{doc.date}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          {doc.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-2 justify-end">
                          <Button variant="ghost" size="sm" className="gap-2">
                            <Eye className="h-4 w-4" />
                            View
                          </Button>
                          <Button variant="ghost" size="sm" className="gap-2">
                            <Brain className="h-4 w-4" />
                            Analyze
                          </Button>
                          <Button variant="ghost" size="sm" className="gap-2">
                            <Download className="h-4 w-4" />
                            Download
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="mt-6">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Action Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {actionLogs.map((log, index) => (
                  <div key={index}>
                    <div className="flex items-start gap-4">
                      <div className="h-2 w-2 rounded-full bg-primary mt-2"></div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p className="font-semibold text-foreground">{log.action}</p>
                          <p className="text-sm text-muted-foreground">{log.timestamp}</p>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{log.description}</p>
                        <p className="text-sm text-primary mt-1">By: {log.user}</p>
                      </div>
                    </div>
                    {index < actionLogs.length - 1 && <Separator className="my-4" />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
