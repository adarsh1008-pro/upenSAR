import { useState } from "react";
import { Search, AlertCircle, ClipboardList, CheckCircle2, Clock } from "lucide-react";
import StatCard from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useNavigate } from "react-router-dom";

const recentInvestigations = [
  {
    id: "SAR-2025-001",
    accountNo: "ACC-456789",
    status: "In Investigation",
    investigator: "John Smith",
    lastUpdated: "2025-10-28",
    severity: "High",
  },
  {
    id: "SAR-2025-002",
    accountNo: "ACC-123456",
    status: "Pending",
    investigator: "Sarah Johnson",
    lastUpdated: "2025-10-27",
    severity: "Medium",
  },
  {
    id: "SAR-2025-003",
    accountNo: "ACC-789012",
    status: "Closed",
    investigator: "Mike Wilson",
    lastUpdated: "2025-10-26",
    severity: "Low",
  },
  {
    id: "SAR-2025-004",
    accountNo: "ACC-345678",
    status: "In Investigation",
    investigator: "Emily Davis",
    lastUpdated: "2025-10-25",
    severity: "High",
  },
];

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-warning/10 text-warning border-warning/20";
      case "In Investigation":
        return "bg-info/10 text-info border-info/20";
      case "Closed":
        return "bg-success/10 text-success border-success/20";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "High":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "Medium":
        return "bg-warning/10 text-warning border-warning/20";
      case "Low":
        return "bg-success/10 text-success border-success/20";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/accounts?search=${searchQuery}`);
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Staff Accountability Reporting System Overview
        </p>
      </div>

      {/* Search Bar */}
      <Card className="mb-8 border-border">
        <CardContent className="p-6">
          <form onSubmit={handleSearch} className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search by account number or customer name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 border-border"
              />
            </div>
            <Button type="submit" size="lg" className="px-8">
              Search
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total SARs Pending"
          value={45}
          description="Awaiting investigation"
          icon={AlertCircle}
          trend={{ value: "12% from last month", positive: false }}
        />
        <StatCard
          title="SARs in Investigation"
          value={28}
          description="Currently being reviewed"
          icon={Clock}
          trend={{ value: "8% from last month", positive: true }}
        />
        <StatCard
          title="SARs Closed"
          value={156}
          description="This month"
          icon={CheckCircle2}
          trend={{ value: "15% from last month", positive: true }}
        />
        <StatCard
          title="High Severity Cases"
          value={12}
          description="Requires immediate attention"
          icon={ClipboardList}
        />
      </div>

      {/* Recent Investigations Table */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-xl">Recent Investigations</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead>SAR ID</TableHead>
                <TableHead>Account No.</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Investigator</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentInvestigations.map((investigation) => (
                <TableRow key={investigation.id} className="border-border hover:bg-muted/50">
                  <TableCell className="font-medium">{investigation.id}</TableCell>
                  <TableCell>{investigation.accountNo}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={getStatusColor(investigation.status)}>
                      {investigation.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={getSeverityColor(investigation.severity)}>
                      {investigation.severity}
                    </Badge>
                  </TableCell>
                  <TableCell>{investigation.investigator}</TableCell>
                  <TableCell>{investigation.lastUpdated}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`/accounts/${investigation.accountNo}`)}
                    >
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
