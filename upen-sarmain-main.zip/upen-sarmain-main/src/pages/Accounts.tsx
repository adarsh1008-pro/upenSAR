import { Card, CardContent } from "@/components/ui/card";

export default function Accounts() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-foreground mb-2">Accounts</h1>
      <p className="text-muted-foreground mb-8">Search and manage account records</p>
      
      <Card className="border-border">
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">Account search functionality coming soon</p>
        </CardContent>
      </Card>
    </div>
  );
}
